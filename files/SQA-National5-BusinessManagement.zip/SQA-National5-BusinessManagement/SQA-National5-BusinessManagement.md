# SQA-National5-BusinessManagement

# Course Overview

## Course Specification

* Exam: 90 marks  - 2 hours
* Assignment: 30 marks - approx. 5 hours

This course is suited for learners who are interested in entering the world of business and exploring the activities of different types of business. 



## Course Content
**Understanding business**
* Candidates are introduced to the business environment while developing skills 
* Knowledge and understanding of enterprise,and the role of different types of business organisations in society
* They also learn about the internal and external environments in which organisations operate, and the role of stakeholders in business.

**Management of marketing**
* Candidates develop skills, knowledge and understanding of the importance to organisations of having effective marketing systems
* They learn aboutthe processes and procedures organisations use to maintain competitiveness, and how marketing can be used to communicate effectively with consumers,maximising customer satisfaction

**Management of operations**
* Candidates develop skills, knowledge and understanding ofthe importance to organisations of having effective operations systems. 
* They learn about the processes and procedures used to maintain quality through the effective management of suppliers, inventory, and methods of production in an ethical manner

**Management of people**
* Candidates develop skills, knowledge and understanding of the issues facing organisations when managing people 
* They learn about the theories, concepts and processes relating to human resource management, and how employees contribute to the success of organisations

**Management of finance**
* Candidates develop skills, knowledge and understanding ofthe issues facing organisations when managing finance
* They learn about the basic theories, concepts and processes relating to financial aspects of business, when preparing and interpreting information to solve financial problems facing organisations



# 2014 Past Paper

## Section 1: 30 Marks

### Question 1a (i)
* Decision-making skills
* Financial skills

### Question 1a (ii)
* Good financial skills means that Caroline can avoid overspending
* Goood decision-making skills means that Caroline is more likely to make a good decision so that she can reduce the risk of failure

### Question 1b
* A loan is money which needs to be paid back whereas a grant does not need to be paid back
* A loan will have interest added to the amount owed whereas a grant will not have any interest

### Question 1c
* Good customer service will increase customer loyalty so will increase the sales / profits of the company
* It will also give the company a better reputation so it should encourage new customers to try the business
* Also, Caroline will be able to charge higher prices if she has good customer service

### Question 1d (i)
* Identify a job vacancy
* Create a job description
* Send out application forms

### Question 1d (ii)
The Equality Act 2010 simplifies the current discrimination laws and puts them together into one piece of legislation. It prevents employers from discriminating its employees because of their age, gender, sexual orientation or religion.

### Question 1e (i)
Growth

### Question 1e (ii)
The customers' awareness of the product increases and sales begin to grow rapidly

### Question 2a
* A social enterprise aims to help its cause (i.e. homelessness) whereas a public sector organisation aims to provide a service to the community
* Both a social enterprise (i.e. Big Issue) and a public sector organisation aim to make a difference in the community

### Question 2b (i)
Celebrity endorsements

### Question 2b (ii)
* The Big Issue could use special offers (e.g. buy one get one free) too encourage customers to buy their products
* They could use competitions (i.e. buy the product to possibly win a prize) to encourage customers to buy more products

### Question 2c
* Technological - the growth in apps will reduce demand for proper magazines
* Environmental - the weather (e.g. heavy snow) may prevent vendors from going out to sell the Big Issue

### Question 2d (i)
Road

### Question 2d (ii)
* An advantage is that it allows for door-to-door delivery
* Another advantage is that it can depart at any time (24 hours a day)
* A disadvantage is that there are restrictions to the number of hours a lorry driver can work

### Question 2e
* A factor to consider is the amount of profit to be made
* Another factor is the cost of produce to produce the Big Issue (may include materials / labour costs
* Another factor is the price of other magazines / competitors

## Section 2: 40 Marks

### Question 3a
* An advantage is that items can be reused to make new products
* Another advantage is that it limits the number of items ending up in landfill, so improves the company's reputation
* A disadvantage is that items need to be sorted into different categories which takes time to do
* Another disadvantage is that it may reduce the quality of the products

### Question 3b
* Having too much stock means that goods may go out of date which leads to high wastage costs
* Also, goods may go out of fashion so money is wasted

### Question 3c (i)
* Quality control
* Quality assurance

### Question 3c (ii)
* Quality controol is where items are checked at the end of the production process only
* Quality assurance is where items are checked at every stage of production

### Question 4a
* Fixed costs - costs which do not vary with output or sales 
* Variable costs - costs which vary with output or sales
* Sales revenue - the income received from the sale of goods / services

### Question 4b
* The organisation could change to a new supplier who is cheaper
* They could also reduce wages by limiting the amount of overtime or releasing temporary staff
* They could also move to new premises which is cheaper to reduce the rent

### Question 4c (i)
* Spreadsheets allow formulae to be used to calculate information automatically which reduces human error
* Also, graphs / charts can be used to display information so allows for easier comparison of difficult financial data

### Question 4c (ii)
* Word processing can be used to create documents informing departments of their annual budget figure
* Powerpoints can be used to display financial information at the shareholders' meeting

### Question 5a
* The company collects the CVs / application forms from applicants
* The company creates a shortlist of suitable applicants, by seeking references and comparing application forms 
* The company carries out interviews where they ask the applicant questions to allow for comparison
* The company informs candidates whether they have been successful or not

### Question 5b (i)
* Strike - employees withdraw their labour and is often accompanied by a demonstration
* Go slow - employees produce their work at a slower rate

### Question 5b (ii)
* An impact is that production may slow / stop so therefore the organisation may struggle to produce enough goods to meet demand
* Another impact is that the organisation may find it difficult to recruit staff as they have a poor reputation with potential employees

### Question 5c
* Piece rate is where employees are paid by the units produced whereas time rate is where employees are paid by the hour
* Piece rate means that quality may suffer in order to get quantity whereas time rate may result in a higher standard of output

### Question 6a
* Availability of finance
* Equipment available

### Question 6b
* Land - refers to all natural resources (e.g. farmland, water, coal)
* Labour - this is the workforce (i.e. employees)
* Capital - these are man-made resources (including premises, equipment and machinery)
* Enterprise - the idea for the business (i.e. the person who brings together the other 3 factors)

### Question 6c (i)
* Owners
* Employees

### Question 6c (ii)
* Owners can make major decisions which could lead to mistakes being made resultinng in loss of profit. They can also vary their level of investment which will impact the decisions the organisation can make.
* Employees can vary the quality of work they produce which may result in wastage or complaints.





# 2015 Paper

## Section 1: 30 Marks

### Question 1a
* Teenagers
* People living in Dundee 

### Question 1b (i)
People's Postcode Lottery

### Question 1b (ii)
Voluntary sector

### Question 1b (iii)
Public - organisation which is owned and controlled by the government. It is financed by taxes. 

### Question 1c
A social enterprise uses its profits to help its cause. They are funded by grants and sponsorships.

### Question 1d (i)
* They could post a questionnaire to the homes of customers
* They could also set up a customer focus group

### Question 1d (ii)
* A benefit is that there will be increased customer loyalty so it is easier to promote new products
* Another benefit is that it could increase the company's reputation which attracts more customers so increased sales / profits

### Question 1e (i)
* Website
* Social media

### Question 1e (ii)
* A benefit is that it allows for 24/7 communication
* Another benefit is that communication is possible all over the world

### Question  2a
Secondary sector

### Question 2b
* A feature is that it is owned by shareholders
* Another feature is that the owners have limited liability - personal possessions are not at risk

### Question 2c
* A benefit is that there will be higher brand recognition so less advertising is required 
* Another benefit is that there is increased brand loyalty so you are guaranteed returning customers

### Question 2d (i)
Flow - products are made in stages on an assembly line

### Question 2d (ii)
* A benefit is that it is a fast rate of production so allows the organisation to cope with demand
* Another benefit is that automation can be used so less money needs to be spent on employees wages
* A cost is that there is a lack of variety of products so customers may not pay a premium for mass produced goods

### Question 2e
* On the job - employees are trained in the workplace. Employees will learn processes specific to organisation.
* Off the job - employees are trained away from the workplace. Employees are trained by experts.
* Induction - new employees are trained when they first start at an organisation (e.g. health and safety).

### Question 2f
* Owners (Afzal and Akmal Khushi) - they are interested in the amount of profit they earn, the image of the organisation and a return on their investment
* Employees - interested in their level of pay, good working conditions and their job security



## Section 2: 40 Marks

### Question 3a
* 10 cakes
* £400

### Question 3b
£400 - £200 = £200 / 10 = £20 per unit

### Question 3c
* Break even - where neither a profit or loss is being made as sales are covering the costs 
* Fixed costs - costs which do not vary with output / sales
* Variable costs - cosst which vary directly with output / sales

### Question 3d
* Bank loan - paid back in installments over a long period of time 
* Grant - money does not need to be paid back
* Overdraft - money is available quickly as it can be prearranged. You can take more money than you have in your account.

### Question 4a
* Identify the job vacancy
* Create a job description, stating the roles and responsibilities of the job
* Advertise the job to allow the vacancy to be seen by applicants either internally or externally
* Send out application forms to the candidates

### Question 4b
* Online application forms can be used instead of paper copies
* Online tests / assessments can be used as the first stage of application before an interview
* Databases can be used to store the details of interviewees and search for potential candidates with a specific skill / qualification

### Question 4c
* The employer must create a health and safety policy
* They must also ensure that health and safety training is carried out regularly (e.g. when new legislation is issued)
* They must also ensure that the workplace is safe and prevent risks to health (e.g. provide adequate first aid facilities)

### Question 5a
* An advantage is that it will prevent overstocking and understocking as stock levels will be known at all times 
* Another advantage is that it can be linked to the supplier to order goods when required

### Question 5b
* They can reduce waste by using quality management processes
* They could also recycle packaging / waste products to meet their environmental aims

### Question 5c (i)
* Quality raw materials
* Up-to-date equipment

### Question 5c (ii) 
* Using good quality raw materials will result in a higher quality finished product 
* It will also improve customer satisfaction so customers are more likely to recommend products
* It will also help to improve the image / reputatioon of the organisation 

### Question 6a (i)
* Product - the good / service must meet the needs of the customer
* Place - this is where the customer will purchase the good / service from
* Price - what the customer will have to pay for the good / service

### Question 6a (ii)
* Special offers could be used (e.g. buy one get one free)
* Free samples could be sued to try to encourage customers to try a product 
* Competitions to win prizes could be used to try to encourage customers to buy a product

### Question 6b
* A benefit is that the information already exists so it will be quicker to obtain
* Another benefit is that it is relatively inexpensive to gather and obtain information
* A cost is that the information may be out-of-date so could be inaccurate 
* Another cost is that the information is available to your competitorsn so you do not have a competitve edge





# 2016 Paper

## Section 1: 30 Marks

### Question 1
This question has been removed due to copyright restrictions. 

### Question 2a (i)
'Sweatshop' conditions are not used. 

### Question 2a (ii)
* It can be used as a unique selling point so gives the company a competitive edge. 
* It can improve the image / reputation of the company so that there will be increased sales / profits. 

### Question 2b
* A benefit is that the company gets access to more customers so increased market share.
* Another benefit is that the entire product range can be shown so increases the customer's choice. 
* Another benefit is that customers can shop 24/7 which gives the organisation the maximum time for customers to buy from them.

### Question 2c (i)
Induction training

### Question 2c (ii)
An advantage is that employees will become familiar with the people and surroundings. 

### Question 2d
* Applications forms - contains personal information on a candidate
* Interviews - allows the organisation to ask a series of questions to allow for comparison
* References - provides key information on attendance, attitude and time-keeping

### Question 2e
* Quality control - products are checked at the end of production
* Quality assurance - products are checked at every stage of production to prevent errors
* Quality circles - small groups of employees who meet regularly to discuss how to improve methods of working



## Section 2: 40 Marks

### Question 3a (i)
* Finance
* Technology

### Question 3a (ii)
* Finance - if there is a lack of finance then cost-cutting measures may need to be taken
* Technology - having up-to-date technology will allow the company to produce quality products and give them a competitive edge

### Question 3b 
* They aim to provide a service to others
* They also aim to raise awareness of issues

### Question 3c
* An advantage is that the owner can keep all of the profits
* Another advantage is that the owner can make all of the decisions
* A disadvantage is that there is no one to share ideas with
* Another disadvantage is that there is unlimited liability - personal possessions are at risk if the business fails

### Question 4a (i)
Create a job advert or application form

### Question 4a (ii)
Store details of the applicants

### Question 4a (iii)
Use an online application form

### Question 4b (i)
* Strike
* Go Slow

### Question 4b (ii)
* Production within the organisation may slow down or stop so the company may struggle to cope with demand
* Employees refusing to work means that deadlines will not be met 
* Decreased levels of production means that the company's reputation may be damaged

### Question 4c
* Video conferencing allows employees to have meetings in different locations which results in less travel time and cost
* Work can be completed outside of the 'traditional' working hours

### Question 5a (i)
* Increased wages
* Increased purchases

### Question 5a (ii)
* Reduce the number of employees to reduce wages, or do not allow overtime
* Find a cheaper supplier to reduce the costs of purchases

### Question 5b (i)
Advertising

### Question 5b (ii)
Purchases

### Question 5c
* To calculate the profit for the year
* To calculate the total cost of expenses
* For legal / tax reasons

### Question 6a
* Job - where a unique product is made completely before starting the next one
* Batch - where groups of similar products are produced. Machinery is cleaned before moving onto the next batch
* Flow - identical products are made along an assembly line

### Question 6b
* A factor is that the delivery time needs to meet the needs of the organisation 
* The location of the supplier must be considered as it may impact the delivery (lead) time
* The quality of the raw materials must be consistent

### Question 6c
* Overstocking:
	* Becomes harder to cope with unexpected orders so customers may leave
	* Production may have to stop completely which means paying for cutomers who are not producing anything

* Understocking:
	* Company has to carry large amounts of stock which increases cost which decreases profit
	* Capital is tied up in stock which means money cannot be used elsewhere



